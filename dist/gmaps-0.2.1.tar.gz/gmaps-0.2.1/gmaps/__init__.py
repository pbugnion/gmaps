
from gmaps.loader import init
from gmaps.heatmap import heatmap
from gmaps.plainmap import plainmap

import gmaps.datasets as datasets

from IPython.display import display

__version__ = "0.2.1"

init()
